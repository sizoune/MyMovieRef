package com.wildan.mymovieref.data.repository

import com.wildan.mymovieref.data.model.Movie

object MovieRepository {

    private const val prefixImagePath = "https://image.tmdb.org/t/p/original"

    fun generatePopularMovies(): List<Movie> {
        val movies = ArrayList<Movie>()

        movies.add(
            Movie(
                "$prefixImagePath/5UkzNSOK561c2QRy2Zr4AkADzLT.jpg",
                528085,
                "en",
                "A lowly utility worker is called to the future by a mysterious radio signal, he must leave his dying wife to embark on a journey that will force him to face his deepest fears in an attempt to change the fabric of reality and save humankind from its greatest environmental crisis yet.",
                "$prefixImagePath/7D430eqZj8y3oVkLFfsWXGRcpEG.jpg",
                "2020-10-01",
                "2067",
                5.8,
                "https://www.themoviedb.org/movie/528085-2067"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/aO5ILS7qnqtFIprbJ40zla0jhpu.jpg",
                741067,
                "en",
                "While searching for her missing mother, intrepid teen Enola Holmes uses her sleuthing skills to outsmart big brother Sherlock and help a runaway lord.",
                "$prefixImagePath/elZ6JCzSEvFOq4gNjNeZsnRFsvj.jpg",
                "2020-09-29",
                "Welcome to Sudden Death",
                6.7,
                "https://www.themoviedb.org/movie/741067"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/kMe4TKMDNXTKptQPAdOF0oZHq3V.jpg",
                497582,
                "en",
                "Jesse Freeman is a former special forces officer and explosives expert now working a regular job as a security guard in a state-of-the-art basketball arena. Trouble erupts when a tech-savvy cadre of terrorists kidnap the team's owner and Jesse's daughter during opening night. Facing a ticking clock and impossible odds, it's up to Jesse to not only save them but also a full house of fans in this highly charged action thriller.",
                "$prefixImagePath/riYInlsq2kf1AWoGm80JQW5dLKp.jpg",
                "2020-09-23",
                "Enola Holmes",
                7.6,
                "https://www.themoviedb.org/movie/497582"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/zzWGRw277MNoCs3zhyG3YmYQsXv.jpg",
                337401,
                "en",
                "When the Emperor of China issues a decree that one man per family must serve in the Imperial Chinese Army to defend the country from Huns, Hua Mulan, the eldest daughter of an honored warrior, steps in to take the place of her ailing father. She is spirited, determined and quick on her feet. Disguised as a man by the name of Hua Jun, she is tested every step of the way and must harness her innermost strength and embrace her true potential.",
                "$prefixImagePath/aKx1ARwG55zZ0GpRvU2WrGrCG9o.jpg",
                "2020-09-04",
                "Mulan",
                7.3,
                "https://www.themoviedb.org/movie/337401"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/86L8wqGMDbwURPni2t7FQ0nDjsH.jpg",
                724989,
                "en",
                "The work of billionaire tech CEO Donovan Chalmers is so valuable that he hires mercenaries to protect it, and a terrorist group kidnaps his daughter just to get it.",
                "$prefixImagePath/ugZW8ocsrfgI95pnQ7wrmKDxIe.jpg",
                "2020-08-25",
                "Hard Kill",
                4.7,
                "https://www.themoviedb.org/movie/724989"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/pq0JSpwyT2URytdFG0euztQPAyR.jpg",
                694919,
                "en",
                "A professional thief with $40 million in debt and his family's life on the line must commit one final heist - rob a futuristic airborne casino filled with the world's most dangerous criminals.",
                "$prefixImagePath/6CoRTJTmijhBLJTUNoVSUNxZMEI.jpg",
                "2020-09-29",
                "Money Plane",
                6.1,
                "https://www.themoviedb.org/movie/694919"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/7WKIOXJa2JjHygE8Yta3uaCv6GC.jpg",
                697064,
                "en",
                "A contract killer, becomes the reverend of a LA church, until a cult leader and his minions kidnap his daughter. Blinded by vengeance, he cuts a bloody path across the city. The only thing that can stop him is his newfound faith.",
                "$prefixImagePath/z0r3YjyJSLqf6Hz0rbBAnEhNXQ7.jpg",
                "2020-09-10",
                "Beckman",
                5.4,
                "https://www.themoviedb.org/movie/697064"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/x4UkhIQuHIJyeeOTdcbZ3t3gBSa.jpg",
                718444,
                "en",
                "Battle-hardened O’Hara leads a lively mercenary team of soldiers on a daring mission: rescue hostages from their captors in remote Africa. But as the mission goes awry and the team is stranded, O’Hara’s squad must face a bloody, brutal encounter with a gang of rebels.",
                "$prefixImagePath/uOw5JD8IlD546feZ6oxbIjvN66P.jpg",
                "2020-08-20",
                "Rogue",
                5.9,
                "https://www.themoviedb.org/movie/718444"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/7fvdg211A2L0mHddvzyArRuRalp.jpg",
                734309,
                "en",
                "Two brothers — one a narcotics agent and the other a general — finally discover the identity of the drug lord who murdered their parents decades ago. They may kill each other before capturing the bad guys.",
                "$prefixImagePath/9Rj8l6gElLpRL7Kj17iZhrT5Zuw.jpg",
                "2020-08-28",
                "Santana",
                5.6,
                "https://www.themoviedb.org/movie/734309"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/54yOImQgj8i85u9hxxnaIQBRUuo.jpg",
                539885,
                "en",
                "A black ops assassin is forced to fight for her own survival after a job goes dangerously wrong.",
                "$prefixImagePath/qzA87Wf4jo1h8JMk9GilyIYvwsA.jpg",
                "2020-07-02",
                "Ava",
                5.9,
                "https://www.themoviedb.org/movie/539885"
            )
        )

        return movies
    }

    fun generatePopularTVSeries(): List<Movie> {
        val movies = ArrayList<Movie>()

        movies.add(
            Movie(
                "$prefixImagePath/mGVrXeIjyecj6TKmwPVpHlscEmw.jpg",
                76479,
                "en",
                "A group of vigilantes known informally as “The Boys” set out to take down corrupt superheroes with no more than blue-collar grit and a willingness to fight dirty.",
                "$prefixImagePath/mY7SeH4HFFxW1hiI6cWuwCRKptN.jpg",
                "2019-07-25",
                "The Boys",
                8.4,
                "https://www.themoviedb.org/tv/76479"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/58PON1OrnBiX6CqEHgeWKVwrCn6.jpg",
                62286,
                "en",
                "What did the world look like as it was transforming into the horrifying apocalypse depicted in \"The Walking Dead\"? This spin-off set in Los Angeles, following new characters as they face the beginning of the end of the world, will answer that question.",
                "$prefixImagePath/wGFUewXPeMErCe2xnCmmLEiHOGh.jpg",
                "2015-08-23",
                "Fear the Walking Dead",
                7.3,
                "https://www.themoviedb.org/tv/62286"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/ta5oblpMlEcIPIS2YGcq9XEkWK2.jpg",
                63174,
                "en",
                "Bored and unhappy as the Lord of Hell, Lucifer Morningstar abandoned his throne and retired to Los Angeles, where he has teamed up with LAPD detective Chloe Decker to take down criminals. But the longer he's away from the underworld, the greater the threat that the worst of humanity could escape.",
                "$prefixImagePath/4EYPN5mVIhKLfxGruy7Dy41dTVn.jpg",
                "016-01-25",
                "Lucifer",
                8.5,
                "https://www.themoviedb.org/tv/63174"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/pLVrN9B750ehwTFdQ6n3HRUERLd.jpg",
                94305,
                "en",
                "A heroic group of teens sheltered from the dangers of the post-apocalyptic world leave the safety of the only home they have ever known and embark on a cross-country journey to find the one man who can possibly save the world.",
                "$prefixImagePath/z31GxpVgDsFAF4paZR8PRsiP16D.jpg",
                "2020-10-04",
                "The Walking Dead: World Beyond",
                7.8,
                "https://www.themoviedb.org/tv/94305"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/isevY1UDcpaAYlYo7IqoSAU9s81.jpg",
                109958,
                "en",
                "After an au pair’s tragic death, Henry Wingrave hires a young American nanny to care for his orphaned niece and nephew who reside at Bly Manor with the estate’s chef Owen, groundskeeper Jamie and housekeeper, Mrs. Grose. But all is not as it seems at the manor, and centuries of dark secrets of love and loss are waiting to be unearthed in this chilling gothic romance. At Bly Manor, dead doesn’t mean gone.",
                "$prefixImagePath/vIXQ8UymmQ7zJEPrKJP3s3fSbhR.jpg",
                "2020-10-09",
                "The Haunting of Bly Manor",
                7.7,
                "https://www.themoviedb.org/tv/109958"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/nVRyd8hlg0ZLxBn9RaI7mUMQLnz.jpg",
                1622,
                "en",
                "When they were boys, Sam and Dean Winchester lost their mother to a mysterious and demonic supernatural force. Subsequently, their father raised them to be soldiers. He taught them about the paranormal evil that lives in the dark corners and on the back roads of America ... and he taught them how to kill it. Now, the Winchester brothers crisscross the country in their '67 Chevy Impala, battling every kind of supernatural threat they encounter along the way. ",
                "$prefixImagePath/KoYWXbnYuS3b0GyQPkbuexlVK9.jpg",
                "2005-09-13",
                "Supernatural",
                8.1,
                "https://www.themoviedb.org/tv/1622"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/9hvhGtcsGhQY58pukw8w55UEUbL.jpg",
                69050,
                "en",
                "Set in the present, the series offers a bold, subversive take on Archie, Betty, Veronica and their friends, exploring the surreality of small-town life, the darkness and weirdness bubbling beneath Riverdale’s wholesome facade.",
                "$prefixImagePath/4X7o1ssOEvp4BFLim1AZmPNcYbU.jpg",
                "2017-01-26",
                "Riverdale",
                8.6,
                "https://www.themoviedb.org/tv/69050"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/hTExot1sfn7dHZjGrk0Aiwpntxt.jpg",
                48866,
                "en",
                "100 years in the future, when the Earth has been abandoned due to radioactivity, the last surviving humans live on an ark orbiting the planet — but the ark won't last forever. So the repressive regime picks 100 expendable juvenile delinquents to send down to Earth to see if the planet is still habitable.",
                "$prefixImagePath/wcaDIAG1QdXQLRaj4vC1EFdBT2.jpg",
                "2014-03-19",
                "The 100",
                7.7,
                "https://www.themoviedb.org/tv/48866"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/iW74tZ8y2qobdpt4J9UQ71sw8q7.jpg",
                82596,
                "en",
                "When ambitious Chicago marketing exec Emily unexpectedly lands her dream job in Paris, she embraces a new life as she juggles work, friends and romance.",
                "$prefixImagePath/kwMqIYOC4U9eK4NZnmmyD8pDEOi.jpg",
                "2020-10-02",
                "Emily in Paris",
                8.2,
                "https://www.themoviedb.org/tv/82596"
            )
        )

        movies.add(
            Movie(
                "$prefixImagePath/g63KmFgqkvXu6WKS23V56hqEidh.jpg",
                77169,
                "en",
                "This Karate Kid sequel series picks up 30 years after the events of the 1984 All Valley Karate Tournament and finds Johnny Lawrence on the hunt for redemption by reopening the infamous Cobra Kai karate dojo. This reignites his old rivalry with the successful Daniel LaRusso, who has been working to maintain the balance in his life without mentor Mr. Miyagi.",
                "$prefixImagePath//eTMMU2rKpZRbo9ERytyhwatwAjz.jpg",
                "2018-05-02",
                "Cobra Kai",
                8.0,
                "https://www.themoviedb.org/tv/77169"
            )
        )

        return movies
    }

}