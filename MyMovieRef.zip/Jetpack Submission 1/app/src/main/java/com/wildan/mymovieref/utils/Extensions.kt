@file:Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")

package com.wildan.mymovieref.utils

import java.text.SimpleDateFormat
import java.util.*

fun String.formatToMMMddyyyy(defaultPattern: String): String {
    val formatter = SimpleDateFormat(defaultPattern, Locale.getDefault())
    val sdf = SimpleDateFormat("MMM, dd yyyy", Locale.getDefault())
    return sdf.format(formatter.parse(this))
}

