package com.wildan.mymovieref.data.model

class ResponseListObject<T>(val results: List<T>) : BaseResponse()