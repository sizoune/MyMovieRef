package com.wildan.mymovieref.ui.detail

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.ShareActionProvider
import androidx.core.view.MenuItemCompat
import androidx.lifecycle.ViewModelProvider
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.wildan.mymovieref.R
import com.wildan.mymovieref.data.model.Movie
import com.wildan.mymovieref.databinding.ActivityDetailBinding
import com.wildan.mymovieref.ui.detail.viewmodel.DetailMovieViewModel
import com.wildan.mymovieref.utils.formatToMMMddyyyy

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewModel: DetailMovieViewModel
    private lateinit var detailMovie: Movie
    private lateinit var myShareActionProvider: ShareActionProvider
    private var category: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        viewModel = ViewModelProvider(
            this
        ).get(DetailMovieViewModel::class.java)

        setupUI()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.sharing_menu, menu)
        menu?.let {
            val shareItem = menu.findItem(R.id.menuShare)
            myShareActionProvider =
                MenuItemCompat.getActionProvider(shareItem) as ShareActionProvider
            setData()
            myShareActionProvider.setShareIntent(shareData())
        }
        return true
    }

    private fun setupUI() {
        setSupportActionBar(binding.toolbarLayout.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbarLayout.collapsingToolbar.setExpandedTitleColor(Color.TRANSPARENT)
    }

    private fun setData() {
        category = intent.getStringExtra("category")
        category?.let { category ->
            val movieID = intent.getIntExtra("data", -1)
            if (category == "movie" && movieID != -1) {
                val movie = viewModel.getDetailMovie(movieID)
                movie?.let { dataMovie ->
                    bindData(dataMovie)
                }
            }
            if (category == "tv" && movieID != -1) {
                val movie = viewModel.getDetailTV(movieID)
                movie?.let { dataMovie ->
                    bindData(dataMovie)
                }
            }
        }

    }

    private fun bindData(movie: Movie) {
        detailMovie = movie
        binding.posterImage.loadImageFromURL(movie.posterPath)
        binding.toolbarLayout.coverImage.loadImageFromURL(movie.backdropPath)
        binding.movieTitle.text = movie.title
        binding.releaseDate.text = movie.releaseDate.formatToMMMddyyyy("yyy-MM-dd")
        binding.txtDesc.text = movie.overview
        changeShareIntent(shareData())
    }

    private fun shareData(): Intent? {
        if (::detailMovie.isInitialized) {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT, detailMovie.urlDetail)
            return shareIntent
        }

        return null
    }

    private fun changeShareIntent(shareIntent: Intent?) {
        myShareActionProvider.setShareIntent(shareIntent)
    }

    private fun ImageView.loadImageFromURL(url: String) {
        val circularProgressDrawable = CircularProgressDrawable(context)
        circularProgressDrawable.strokeWidth = 5f
        circularProgressDrawable.centerRadius = 30f
        circularProgressDrawable.start()
        Glide.with(context)
            .load(url)
            .apply(
                RequestOptions.placeholderOf(circularProgressDrawable)
                    .error(R.drawable.ic_broken_image)
            )
            .into(this)
    }
}