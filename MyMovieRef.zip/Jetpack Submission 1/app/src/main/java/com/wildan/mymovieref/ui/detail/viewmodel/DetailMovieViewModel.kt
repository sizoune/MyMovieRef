package com.wildan.mymovieref.ui.detail.viewmodel

import androidx.lifecycle.ViewModel
import com.wildan.mymovieref.data.model.Movie
import com.wildan.mymovieref.data.repository.MovieRepository

class DetailMovieViewModel : ViewModel() {

    fun getDetailMovie(movieId: Int): Movie? {
        val dummy = MovieRepository.generatePopularMovies()
        return dummy.find { data -> data.id == movieId }
    }

    fun getDetailTV(tvID: Int): Movie? {
        val dummy = MovieRepository.generatePopularTVSeries()
        return dummy.find { data -> data.id == tvID }
    }


}