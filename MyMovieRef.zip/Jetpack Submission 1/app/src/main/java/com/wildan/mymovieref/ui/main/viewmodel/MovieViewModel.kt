package com.wildan.mymovieref.ui.main.viewmodel

import androidx.lifecycle.ViewModel
import com.wildan.mymovieref.data.model.Movie
import com.wildan.mymovieref.data.repository.MovieRepository

class MovieViewModel : ViewModel() {

    fun getMoviePopularList(): List<Movie> = MovieRepository.generatePopularMovies()

    fun getTVSeriesPopularList(): List<Movie> = MovieRepository.generatePopularTVSeries()

}