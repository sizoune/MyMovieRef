package com.wildan.mymovieref.ui.main.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.wildan.mymovieref.databinding.FragmentTVSeriesBinding
import com.wildan.mymovieref.ui.detail.DetailActivity
import com.wildan.mymovieref.ui.main.adapter.MovieAdapter
import com.wildan.mymovieref.ui.main.viewmodel.MovieViewModel

class TVSeriesFragment : Fragment() {

    private lateinit var pageViewModel: MovieViewModel
    private var _binding: FragmentTVSeriesBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pageViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[MovieViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentTVSeriesBinding.inflate(inflater, container, false)
        binding.listTV.layoutManager = LinearLayoutManager(context)
        binding.listTV.adapter = MovieAdapter(pageViewModel.getTVSeriesPopularList()) {
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("data", it)
            intent.putExtra("category","tv")
            startActivity(intent)
        }
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        @JvmStatic
        fun newInstance(): TVSeriesFragment {
            return TVSeriesFragment()
        }
    }
}