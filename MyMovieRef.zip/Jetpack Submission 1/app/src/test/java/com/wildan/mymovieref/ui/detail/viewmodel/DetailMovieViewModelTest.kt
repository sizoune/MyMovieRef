package com.wildan.mymovieref.ui.detail.viewmodel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class DetailMovieViewModelTest {

    private lateinit var detailViewModel: DetailMovieViewModel
    private var expectedMovieTitle = "Hard Kill"
    private var expectedSeriesTitle = "Fear the Walking Dead"
    private var movieID = 724989
    private var TVID = 62286

    @Before
    fun setUp() {
        detailViewModel = DetailMovieViewModel()
    }

    @Test
    fun getDetailMovie() {
        val detailMovie = detailViewModel.getDetailMovie(movieID)
        assertNotNull(detailMovie)
        assertEquals(expectedMovieTitle, detailMovie?.title)
    }

    @Test
    fun getDetailTV() {
        val detailSeries = detailViewModel.getDetailTV(TVID)
        assertNotNull(detailSeries)
        assertEquals(expectedSeriesTitle, detailSeries?.title)
    }
}