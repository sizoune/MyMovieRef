package com.wildan.mymovieref.ui.main.viewmodel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class MovieViewModelTest {

    private lateinit var mainViewModel: MovieViewModel
    private var expectedListSize = 10

    @Before
    fun setViewModel() {
        mainViewModel = MovieViewModel()
    }

    // menguji apakah list popular movie tidak null dan berjumlah 10
    @Test
    fun getMoviePopularList() {
        val popularMovies = mainViewModel.getMoviePopularList()
        assertNotNull(popularMovies)
        assertEquals(expectedListSize, popularMovies.size)
    }

    // menguji apakah list popular TV tidak null dan berjumlah 10
    @Test
    fun getTVSeriesPopularList() {
        val popularSeries = mainViewModel.getTVSeriesPopularList()
        assertNotNull(popularSeries)
        assertEquals(expectedListSize, popularSeries.size)
    }
}